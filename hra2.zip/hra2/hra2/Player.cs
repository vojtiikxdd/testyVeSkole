﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hra2
{
    public class Player
    {
        public string name;
        public int level;
        public int positionX;
        public int positionY;

        public Player(string name) { }
        public void changePosition(int x, int y)
        {
            
        }
    }

    public class Gamer : Player
    {
        public string role;
        public int faceExpression;
        public int hair;
        public int hairColor;
        public int xp;

        public Gamer(string name) : base(name)
        {
            
        }

        public void levelUp(int xp)
        {
            
        }
    }

    public class NPC : Player
    {
        public string occupation;
        public bool boss;

        public NPC(string name) : base(name)
        {

        }
    }
}
