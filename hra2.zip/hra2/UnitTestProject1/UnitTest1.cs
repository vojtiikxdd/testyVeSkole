﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using hra2; 

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void ArePositionXInitialized()
        {
            Player player = new Player("kokot");
            Assert.AreEqual(player.positionX, 0);
        }

        [TestMethod]
        public void ArePositionYInitialized()
        {
            Player player = new Player("kokot");
            Assert.AreEqual(player.positionY, 0);
        }

        [TestMethod]
        public void CanChangePosition()
        {
            Player player = new Player("kokot");
            player.changePosition(5, 5);
            Assert.AreEqual(player.positionX, 5);
            Assert.AreEqual(player.positionY, 5);
        }

        [TestMethod]
        public void NameLenght()
        {
            Player player = new Player("kokot");
            Assert.IsTrue(player.name.Length <= 10);
        }

        [TestMethod]
        public void IsLevelInitialized()
        {
            Player player = new Player("kokot");
            Assert.AreEqual(player.level, 1);
        }

        [TestMethod]
        public void IsRole()
        {
            Gamer gamer = new Gamer("malykokot");
            string[] pole = new string[] {"Kouzelník", "Berserker", "Inženýr", "Cizák"};

            CollectionAssert.Contains(pole, gamer.role);
        }

        [TestMethod]
        public void IsFaceExpression()
        {
            Gamer gamer = new Gamer("malykokot");
            Assert.AreEqual(gamer.faceExpression, 0);
        }

        [TestMethod]
        public void IsHair()
        {
            Gamer gamer = new Gamer("malykokot");
            Assert.AreEqual(gamer.hair, 0);
        }

        [TestMethod]
        public void IsHairColor()
        {
            Gamer gamer = new Gamer("malykokot");
            Assert.AreEqual(gamer.hairColor, 0);
        }

        [TestMethod]
        public void IsXP()
        {
            Gamer gamer = new Gamer("malykokot");
            Assert.AreEqual(gamer.xp, 0);
        }

        [TestMethod]
        public void IsLevelUp()
        {
            Gamer gamer = new Gamer("malyKokot");
            gamer.levelUp(100);

            Assert.AreEqual(gamer.level, 2);
        }

        [TestMethod]
        public void GamerInfo()
        {
            Gamer gamer = new Gamer("malykokot");
            Assert.AreEqual("info o hráči", gamer.ToString());
        }

        [TestMethod]
        public void PlayerInfo()
        {
            Player player = new Player("kokot");
            Assert.AreEqual("info o herní postavě", player.ToString());
        }

        [TestMethod]
        public void NPCInfo()
        {
            NPC npc = new NPC("kokot");
            Assert.AreEqual("info o herní postavě", npc.ToString());
        }

        [TestMethod]
        public void NPCChangePosition()
        {
            NPC npc = new NPC("velkykokot");

            npc.changePosition(5, 5);

            Assert.AreEqual(npc.positionY, 0);
            Assert.AreEqual(npc.positionX, 0);
        }
    }
}
